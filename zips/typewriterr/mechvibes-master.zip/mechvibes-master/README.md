![Mechvibes](https://i.imgur.com/78qUULA.jpg)

# Mechvibes

It's a side project that I made for myself since when I use my own mechanical keyboard at late night or in the office and my parents and my coworkers hate that a lot because the sound of the keyboard is very loud (especially in quiet places). So if you are facing this issue just like me then this product is for you!

- You can add more keyboard sound set by recording any sound you like and add them to this app with some easy steps.

- Use your laptop keyboard or non-mechanical keyboard at work and still hear your loved sound.

- Use this app as any purpose as you want (such as demo for the buyer about the keyboard sound before they buy it, custom any sound for any key...)

With Mechvibes Editor, you can create a new sound pack, edit existing sound pack or share them with your friends.

### How to use

- Download it from [Releases](https://github.com/hainguyents13/mechvibes/releases/latest)
- Run it.
- Enjoy it.

### Issues

🤝 Any ideas are welcomed!
