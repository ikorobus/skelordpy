# random typewriter sound effects for Renpy


The default right now is both sounds being utilized, so check the lines of code referencing what selection of sounds to use and tweak it to your liking.

# Instructions
The file is example.rpy in the list above, either download it and open it in your text editor of choice or open the file in github and copy the text.

Place the code at the start of your script.rpy folder.

In the code you will find the option to switch from light taps, to soft taps, to both.

When you want to use it in your project, remove anything in this effect's "label start" section as that's merely just an example for you to check if it's working.


Don't accidentally delete your own start label though.


 ...
   


Download the audio here:
https://mega.nz/folder/Wqo0iDBC#w8MBBUyBqXzdD4YAaBclgg

Place the sounds in the audio folder. I created these sound effects myself as other sources may be copyrighted.

# If the audio is unavailable, message me on twitter @aquapaulo
